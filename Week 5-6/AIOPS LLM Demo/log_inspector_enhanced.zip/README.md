# 🔍 Log Inspector — Local Log File Analyzer using LLM (Gemma via Ollama)

This is a Streamlit-based tool that allows users to upload a log file and ask natural language questions about its contents. It uses a local LLM (Gemma 2B) via [Ollama](https://ollama.com) to analyze the logs without any internet-based APIs.

(Full instructions continue as written in previous response.)
