
import subprocess

def ask_llm_ollama(prompt, model="gemma"):
    """
    Run a prompt against a locally installed Ollama model (e.g. gemma).
    Works on Windows using subprocess.
    """
    try:
        process = subprocess.Popen(
            ["ollama", "run", model],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True  # Important for Windows
        )
        stdout, stderr = process.communicate(input=prompt)
        if stderr:
            return f"[ERROR]: {stderr}"
        return stdout
    except Exception as e:
        return f"[EXCEPTION]: {str(e)}"
