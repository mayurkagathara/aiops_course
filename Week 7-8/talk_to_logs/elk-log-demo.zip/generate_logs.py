#!/usr/bin/env python3
"""
Python log generator that writes realistic app logs (NOT JSON) embedding key fields.
Output format:
YYYY-MM-DD HH:MM:SS,mmm LEVEL [application_name] (customer=<id>, customer_name=<name>, environment=<env>, log_type=<type>) <message>
"""
import os
import random
from datetime import datetime, timedelta

CUSTOMERS = [
    ("cust001", "Acme Corp"),
    ("cust002", "Beta Industries"),
    ("cust003", "Gamma Labs"),
    ("cust004", "Delta Systems"),
    ("cust005", "Omega Retail")
]

ENVIRONMENTS = ["dev", "test", "stage", "prod"]
APPLICATIONS = ["auth-service", "payment-service", "inventory-service", "user-service", "reporting-service"]
LOG_TYPES = ["app", "lb", "tomcat"]
LEVELS = ["INFO", "WARN", "ERROR"]

API_PATHS = [
    "/auth/login", "/auth/logout", "/payments/charge", "/payments/refund",
    "/inventory/items", "/inventory/update", "/users/profile", "/reports/daily"
]

ERROR_MESSAGES = [
    "DB connection timeout",
    "NullPointerException at ServiceLayer",
    "Invalid token provided",
    "Upstream service unavailable",
    "Cache miss; fallback to DB",
    "Circuit breaker open; request denied",
    "Failed to parse JSON payload",
    "Permission denied for user role"
]

def random_message(level: str) -> str:
    if level == "INFO":
        path = random.choice(API_PATHS)
        ms = random.randint(20, 1000)
        return f"Request to {path} completed in {ms}ms"
    elif level == "WARN":
        path = random.choice(API_PATHS)
        ms = random.randint(800, 3000)
        return f"Slow response on {path}; took {ms}ms"
    else:  # ERROR
        return random.choice(ERROR_MESSAGES)

def main(out_path: str = "logs/app.log", n_lines: int = 1000):
    os.makedirs(os.path.dirname(out_path), exist_ok=True)

    # generate timestamps over the last 7 days
    now = datetime.now()
    start = now - timedelta(days=7)

    with open(out_path, "w", encoding="utf-8", newline="\n") as f:
        for _ in range(n_lines):
            cust_id, cust_name = random.choice(CUSTOMERS)
            env = random.choice(ENVIRONMENTS)
            app = random.choice(APPLICATIONS)
            ltype = random.choice(LOG_TYPES)
            level = random.choices(LEVELS, weights=[0.7, 0.2, 0.1])[0]

            # random timestamp
            delta = random.random() * (now - start).total_seconds()
            ts = start + timedelta(seconds=delta)
            ts_str = ts.strftime("%Y-%m-%d %H:%M:%S") + f",{random.randint(0,999):03d}"

            msg = random_message(level)

            line = (f"{ts_str} {level} [{app}] "
                    f"(customer={cust_id}, customer_name={cust_name}, environment={env}, log_type={ltype}) "
                    f"{msg}")
            f.write(line + "\n")

if __name__ == "__main__":
    main()
