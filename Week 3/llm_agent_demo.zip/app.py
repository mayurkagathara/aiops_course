from agent import route_query

def main():
    print("🤖 AIOps LLM Agent. Ask me about incidents or automation.")
    while True:
        q = input("You: ")
        if q.lower() in ["exit", "quit"]:
            break
        print("Agent:", route_query(q))

if __name__ == "__main__":
    main()
