import pandas as pd

def search_automation(csv_path, query):
    df = pd.read_csv(csv_path)
    matches = df[df['Description'].str.contains(query, case=False)]
    return matches.to_dict(orient='records')
