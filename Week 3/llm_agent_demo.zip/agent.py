from rag.vectorstore import query_vectorstore
from tools.automation_lookup import search_automation

INCIDENT_KEYWORDS = ["root cause", "RCA", "incident", "what happened"]
AUTOMATION_KEYWORDS = ["automation", "automate", "script", "tool"]

def route_query(user_query):
    if any(word in user_query.lower() for word in INCIDENT_KEYWORDS):
        result = query_vectorstore(user_query)
        if result['documents']:
            return f"🧠 Found in incident notes:\n{result['documents'][0][0]}"
        return "No incident data found."

    elif any(word in user_query.lower() for word in AUTOMATION_KEYWORDS):
        result = search_automation("example_data/automations.csv", user_query)
        if result:
            return "🛠️ Automation suggestions:\n" + "\n".join(
                [f"{r['Automation Name']} – {r['Description']}" for r in result])
        return "No matching automation found."

    return "Please clarify your query."
